-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 24, 2024 at 10:27 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tmdt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `congty`
--

CREATE TABLE `congty` (
  `idcty` int(10) unsigned NOT NULL auto_increment,
  `tencty` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `dienthoai` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `fax` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idcty`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `congty`
--

INSERT INTO `congty` (`idcty`, `tencty`, `diachi`, `dienthoai`, `fax`) VALUES
(1, 'Samsung', 'Korea', '', ''),
(2, 'Apple', 'USA', '', ''),
(8, 'Oppo', 'USA', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `dathang`
--

CREATE TABLE `dathang` (
  `iddh` int(11) unsigned NOT NULL auto_increment,
  `idkh` int(11) NOT NULL,
  `id_nhanvien` int(11) NOT NULL,
  `ngaydathang` date NOT NULL,
  `trangthai` int(50) NOT NULL,
  PRIMARY KEY  (`iddh`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `dathang`
--

INSERT INTO `dathang` (`iddh`, `idkh`, `id_nhanvien`, `ngaydathang`, `trangthai`) VALUES
(61, 1, 0, '2024-05-24', 0),
(62, 1, 0, '2024-05-24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dathang_chitiet`
--

CREATE TABLE `dathang_chitiet` (
  `iddh` int(11) NOT NULL,
  `idsp` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  `dongia` float NOT NULL,
  `giamgia` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dathang_chitiet`
--

INSERT INTO `dathang_chitiet` (`iddh`, `idsp`, `soluong`, `dongia`, `giamgia`) VALUES
(61, 43, 1, 8100, 20),
(62, 44, 4, 3100, 20);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `iduser` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ten` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachinhanhang` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `phanquyen` varchar(50) NOT NULL,
  PRIMARY KEY  (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`iduser`, `username`, `password`, `hodem`, `ten`, `diachi`, `diachinhanhang`, `phanquyen`) VALUES
(1, 'hoangnho', '827ccb0eea8a706c4c34a16891f84e7b', '', '', '', '', '0'),
(2, 'test', '827ccb0eea8a706c4c34a16891f84e7b', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `idsp` int(10) unsigned NOT NULL auto_increment,
  `tensp` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL,
  `gia` float NOT NULL,
  `mota` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `hinh` varchar(200) character set utf8 collate utf8_unicode_ci NOT NULL,
  `giamgia` float NOT NULL,
  `idcty` int(11) NOT NULL,
  PRIMARY KEY  (`idsp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`idsp`, `tensp`, `gia`, `mota`, `hinh`, `giamgia`, `idcty`) VALUES
(43, 'iPhone 12', 8100, 'Mới 100%', '1716558192_iphone-12-tim.jpg', 20, 2),
(44, 'Samsung A02', 3100, 'Mới', '1716558213_samsung-galaxy-a02-xanhduong-600x600-200x200.jpg', 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `iduser` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ten` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `phanquyen` int(11) NOT NULL,
  `landangnhapcuoi` datetime NOT NULL,
  PRIMARY KEY  (`iduser`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`iduser`, `username`, `password`, `hodem`, `ten`, `phanquyen`, `landangnhapcuoi`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b', '', '', 0, '0000-00-00 00:00:00');
